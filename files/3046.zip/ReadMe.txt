MyGeneration Template to create a custom .Net Exception type.

Original CodeSmith template by Lance Hunt:
http://weblogs.asp.net/lhunt/archive/2006/08/28/Codesmith-Exception-Template-v1.3.aspx

CodeSmith Template modified by Paul Welter - Argument parameter & implementation.
http://weblogs.asp.net/pwelter34/) 

MyGeneration Template, Xml Comments, and bug fixes by James Curran
http://www.honestillusion.com


Both files (CustomException.zeus & CustomExceptionTypes.cs) must be in the same folder.  (The purpose of CustomExceptionTypes.cs is to have the same enums defined in  both the Interface COde and in the Template COde.)