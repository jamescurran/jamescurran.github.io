namespace CustomExceptionTypes
{
	public enum AccessibilityEnum
	{
		Public,
		Internal
	}
	
	public enum UsingStatementLocationEnum
	{
		AboveNamespace,
		BelowNamespace
	}	
	
	// See http://msdn.microsoft.com/library/default.asp?url=/library/en-us/cpguide/html/cpconhresultsexceptions.asp
	public enum ExceptionHResultEnum
	{
		COR_E_EXCEPTION = unchecked((int)0x80131500), // Preferred
		COR_E_APPLICATION = unchecked((int)0x80131600)
	}	
}