// Example from 
// Generics without Collections
// Copyright � 2006 James M. Curran
using System;

namespace CSExamples
{
    abstract class CompareOps<T> : IComparable<T> where T : IComparable<T>
    {
        public bool IsEqualTo(T rhs)
        {   return this.CompareTo(rhs) == 0;    }

        public bool IsNotEqualTo(T rhs)
        { return this.CompareTo(rhs) != 0; }

        public bool IsLessThan(T rhs)
        { return this.CompareTo(rhs) < 0; }

        public bool IsGreaterThan(T rhs)
        { return this.CompareTo(rhs) > 0; }

        public static bool operator ==(CompareOps<T> lhs, T rhs)
        {   return lhs.IsEqualTo(rhs); }

        public static bool operator !=(CompareOps<T> lhs, T rhs)
        { return lhs.IsNotEqualTo(rhs); }

        public static bool operator <(CompareOps<T> lhs, T rhs)
        { return lhs.IsLessThan(rhs); }

        public static bool operator >(CompareOps<T> lhs, T rhs)
        { return lhs.IsGreaterThan(rhs); }

        public abstract int  CompareTo(T rhs);
        public abstract override int GetHashCode();
    }
}
