// Example from 
// Generics without Collections
// Copyright � 2006 James M. Curran

using System;

namespace CSExamples
{
    class MyInt : CompareOps<MyInt>, IComparable<MyInt>
    {
        int innerInt;
        public MyInt(int i)
        { innerInt = i; }


        #region IComparable<MyInt> Members

        public override int CompareTo(MyInt other)
        {
            return innerInt.CompareTo(other.innerInt);
        }

        #endregion

        public override int GetHashCode()
        {
            return innerInt.GetHashCode();
        }
    }
}
