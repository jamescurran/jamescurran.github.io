// Example from 
// Generics without Collections
// Copyright � 2006 James M. Curran

using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace CSExamples
{
    class ABC : List<string> { } 

    class Program
    {
        static void Main(string[] args)
        {
            //-------------------------------------------------------------------
            DelayedLoad<string> dlStr = new DelayedLoad<string>();
            Console.WriteLine("Is String Valid ? : {0}", dlStr.IsValid);   // False            
            dlStr.Set("Hello, World!");
            Console.WriteLine("Is String Valid ? : {0}", dlStr.IsValid);   //True            
            Console.WriteLine("String =  {0}", dlStr);               

            DelayedLoad<int>      intr = new DelayedLoad<int>();            
            Console.WriteLine("Is Integer Valid ? : {0}", intr.IsValid);  //false    
            //            Console.WriteLine("Integer =  {0}", intr);   // would throw exception   

            intr.Set(5); 
            Console.WriteLine("Is Integer Valid ? : {0}", intr.IsValid);  //true            
            Console.WriteLine("Integer =  {0}", intr);                  
            int i = intr;            // assignment to base type works            
            Console.WriteLine("Integer =  {0}", i);

            //-------------------------------------------------------------------
            Panel pnl = FakeAForm();

            foreach (CheckBox chb in ControlFilter.Only<CheckBox>(pnl.Controls)) 
            { 
                MessageBox.Show("CheckBox " + (chb.Checked ? "IS" : "is NOT") + " checked"); 
            }

            //-------------------------------------------------------------------
            ABC abc = new ABC();
            string str= "hello world";

            Console.WriteLine(IsCollection(abc));
            // Prints �true�

            Console.WriteLine(IsCollection(str));
            // Prints �false�

            //-------------------------------------------------------------------
            MyInt A = new MyInt(5);
            MyInt B = new MyInt(10);
            if (A < B)
                Console.WriteLine(" A < B");


        }

        static bool IsCollection<T>(ICollection<T> coll)
        {
            return true;
        }

        static bool IsCollection(object obj)
        {
            return false;
        }


        static Panel FakeAForm()
        {
           Panel pnl = new System.Windows.Forms.Panel();
           pnl.Controls.Add(new TextBox());
           pnl.Controls.Add(new ListBox());
           pnl.Controls.Add(new CheckBox());
           pnl.Controls.Add(new TextBox());
           pnl.Controls.Add(new CheckBox());
            return pnl;
        }
    }
}
