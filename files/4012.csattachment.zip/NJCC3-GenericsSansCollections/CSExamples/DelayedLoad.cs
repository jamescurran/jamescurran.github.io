using System;

namespace CSExamples
{
    struct DelayedLoad<T>
    {
        private T m_Value;
        private bool m_Valid;

        /// <summary>
        /// Initializes a new instance of the <see cref="DelayedLoad&lt;T&gt;"/> class.
        /// </summary>
        //public DelayedLoad()
        //{
        //    m_Valid = false;
        //}


        /// <summary>
        /// Gets a value indicating whether this instance is valid.
        /// </summary>
        /// <value><c>true</c> if this instance is valid; otherwise, <c>false</c>.</value>
        public bool IsValid
        {
            get
            {
                return m_Valid;
            }
        }

        /// <summary>
        /// Sets the specified value.
        /// </summary>
        /// <param name="value">The value.</param>
        public void Set(T value)
        {
            m_Value = value;
            m_Valid = true;
        }

        /// <summary>
        /// Gets this instance.
        /// </summary>
        /// <returns></returns>
        public T Get()
        {
            if (!this.IsValid)
                throw new ArgumentException("Object needs to be loaded before use");
            return this.m_Value;
        }

        /// <summary>
        /// Implicit operators the specified t.
        /// </summary>
        /// <param name="t">The t.</param>
        /// <returns></returns>
        public static implicit operator T(DelayedLoad<T> t)
        {
            return t.Get();
        }

        /// <summary>
        /// Returns the fully qualified type name of this instance.
        /// </summary>
        /// <returns>
        /// A <see cref="T:System.String"></see> containing a fully qualified type name.
        /// </returns>
        public override string ToString()
        {
            return this.Get().ToString();
        }
    }

}
