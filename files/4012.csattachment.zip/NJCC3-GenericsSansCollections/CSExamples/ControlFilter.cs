// Example from 
// Generics without Collections
// Copyright � 2006 James M. Curran

using System;
using System.Windows.Forms;
using System.Collections.Generic;

namespace CSExamples
{
    static class ControlFilter
    {
        /// <summary>
        /// Returns oly type T controls from collection.
        /// </summary>
        /// <param name="coll">The coll.</param>
        /// <returns></returns>
        public static IEnumerable<T> Only<T>(Control.ControlCollection coll) where T : Control
        {
            return new ControlFilter_impl<T>(coll);
        }

        class ControlFilter_impl<T> : IEnumerable<T> where T : Control
        {
            private Control.ControlCollection m_Coll;
            /// <summary>
            /// Initializes a new instance of the <see cref="ControlFilter_impl&lt;T&gt;"/> class.
            /// </summary>
            /// <param name="coll">The coll.</param>
            public ControlFilter_impl(Control.ControlCollection coll)
            {
                m_Coll = coll;
            }

            /// <summary>
            /// Gets the enumerator.
            /// </summary>
            /// <returns></returns>
            public IEnumerator<T> GetEnumerator()
            {
                foreach (Control ctrl in m_Coll)
                {
                    T ctrlT = ctrl as T;
                    if (ctrlT != null)
                        yield return ctrlT;
                }
            }

            /// <summary>
            /// Gets the enumerator.
            /// </summary>
            /// <returns></returns>
            System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
            {
                return this.GetEnumerator();
            }
        }
    }
}
