' Example from 
' Generics without Collections
' Copyright � 2006 James M. Curran

Module Module1

    Sub Main()
        Dim dlStr As New DelayedLoad(Of String)
        Console.WriteLine("Is String Valid : {0}", dlStr.IsValid)
        dlStr.Setter("Hello World")
        Console.WriteLine("Is String Valid : {0}", dlStr.IsValid)
        Console.WriteLine("String =  {0}", dlStr)

        Dim intr As New DelayedLoad(Of Integer)
        Console.WriteLine("Is Integer Valid ? : {0}", intr.IsValid)  'false    
        'Console.WriteLine("Integer =  {0}", intr);   ' would throw exception   

        intr.Setter(5)
        Console.WriteLine("Is Integer Valid ? : {0}", intr.IsValid)  'true            
        Console.WriteLine("Integer =  {0}", intr)

    End Sub

    Structure DelayedLoad(Of T)
        Dim m_Value As T
        Dim m_Valid As Boolean
        '    Sub New()
        '       m_Valid = False
        '  End Sub
        Public ReadOnly Property IsValid() As Boolean
            Get
                Return Me.m_Valid
            End Get
        End Property
        Public Sub Setter(ByVal value As T)
            Me.m_Value = value
            Me.m_Valid = True
        End Sub
        Public Function Getter() As T
            If Not Me.IsValid Then
                Throw New ArgumentException("Object needs to be loaded before use")
            End If
            Return Me.m_Value
        End Function
        Public Overrides Function ToString() As String
            Return Me.Getter().ToString()
        End Function
        '
        '  Implicit conversion to type T ??????
    End Structure

End Module
