Horse16.exe - Original 16-bit version, for win 3.0 (circa 1990)
Horse32.exe - Win32 port.  Some work done in 1996 for Win95, but finally completed in 2007 for WinXP
Horse.exe - .Net v2.0 version, written from scratch in 2007.

Copyright 1990-2007, James M. Curran
